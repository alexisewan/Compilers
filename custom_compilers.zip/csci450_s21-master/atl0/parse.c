/* parse.c:  This is where the parser should be built. */

/* Get the standard definitions and includes. */
#include "defs.h"

/* External Variables. */
#include "global.h"

/* static "local" variables. */

kv_tree names;

/* Functions for the rules. */

void parse (void)
{

#ifdef TESTSCAN
  /* Debugging the scanner only */
  extern void test_scanner(void);
  test_scanner();
  exit(0);
#endif

  /* Initialize */
  kv_init(&names);

  /* Start the parse */

  /* Stop the program from running */
  generate("halt");
}
