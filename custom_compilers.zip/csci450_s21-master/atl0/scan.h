/* scan.h:  For ATL/0.  Defines the token values. */


/* The tokens. */

typedef enum token_types {
	END, READ, BEGIN, WRITE, INTEGER, PROGRAM, WRITELN, VARIABLE,
	CONST, ID, ASSIGN, PLUS, MINUS, LPAREN, RPAREN, SEMI, COMMA,
	COLON, PERIOD, STRING, SCANEOF
    } token;


/* A prototype. */

extern token scanner (void);
