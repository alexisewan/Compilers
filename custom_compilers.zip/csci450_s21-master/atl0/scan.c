/* scan.c:  The scanner for ATL/0. */

/* Get the common definitions and includes. */
#include "defs.h"
/* Extern variables. */
#include "global.h"

/* Storage for the scanner. */

struct reserved
{
  char *name;
  token value;
} res_words[] = {
    {"end", END},
    {"read", READ},
    {"begin", BEGIN},
    {"write", WRITE},
    {"integer", INTEGER},
    {"program", PROGRAM},
    {"writeln", WRITELN},
    {"variable", VARIABLE}};

/* The scanner.  */
token scanner(void)
{
  int lines = 0;
  int char_place = 0;
  char currChar;
  //clearing last_text
  memset(&last_text[0], 0, sizeof(last_text));
  
  //pulling each char of the text from the src_in and handling it accordingly
  currChar = fgetc(src_in);
  do
  {
    //if the char is a letter, get all of the remaining letter/digit chars then process the token
    if (islower(currChar))
    {
      //getting the remaining letters/digits
      while(islower(currChar) || isdigit(currChar)){
        last_text[char_place] = currChar;
        char_place++;
        currChar = fgetc(src_in);
      }

      //ungetting the last char so it can be processed later
      ungetc(currChar, src_in);

      //checking for keywords
      for (int i = 0; i < 8; i++)
      {
        if (strcmp(last_text, res_words[i].name) == 0)
        {
          return res_words[i].value;
        }
      }

      //if it's not a keyword, it must be an ID
      return ID;
    }
    //if the char is a digit, get the remaining digits and return CONST
    else if (isdigit(currChar)){
      while(isdigit(currChar)){
        last_text[char_place] = currChar;
        char_place++;
        currChar = fgetc(src_in);
      }
      ungetc(currChar, src_in);
      return CONST;
    }
    //handle the special chars
    else
    {
      switch (currChar)
      {
      case ' ':
        //do nothing for spaces
        break;
      case ';':
        last_text[0] = currChar;
        return SEMI;
        break;
      case '<':
        //verify that the next two chars are '-', else error
        last_text[0] = currChar;
        if (fgetc(src_in) == '-' && fgetc(src_in) == '-')
        {
          last_text[1] = '-';
          last_text[2] = '-';
          return ASSIGN;
        }
        else
        {
          error("Incomplete ASSIGN token.");
        }
        break;
      case '"':
        //get rest of the string up until the next '"', or error if EOF occurs before next '"'
        currChar = fgetc(src_in);
        do
        {
          last_text[char_place] = currChar;
          char_place++;
          currChar = fgetc(src_in);
        } while (currChar != '"' && currChar != EOF);
        
        if(currChar == EOF){
          error("Reached the EOF before finished reading a STRING");
        }
        return STRING;
        break;
      case '+':
        last_text[0] = currChar;
        break;
      case '-':
        last_text[0] = currChar;
        return MINUS;
        break;
      case '(':
        last_text[0] = currChar;
        return LPAREN;
        break;
      case ')':
        last_text[0] = currChar;
        return RPAREN;
        break;
      case ':':
        last_text[0] = currChar;
        return COLON;
        break;
      case ',':
        last_text[0] = currChar;
        return COMMA;
        break;
      case '.':
        last_text[0] = currChar;
        return PERIOD;
        break;
      case '\n':
        line_no++;
        break;
      default:
        error("Invalid character: %c", currChar);
        break;
      }
    }
    //getting next character
    currChar = fgetc(src_in);
  } while (currChar != EOF);
  return SCANEOF;
}

#ifdef TESTSCAN

char *tok_names[] = {"END", "READ", "BEGIN", "WRITE", "INTEGER", "PROGRAM",
                     "WRITELN", "VARIABLE", "CONST", "ID", "ASSIGN", "PLUS",
                     "MINUS", "LPAREN", "RPAREN", "SEMI", "COMMA", "COLON",
                     "PERIOD", "STRING", "SCANEOF"};

/* debugging only */
void test_scanner(void)
{
  token tok;
  last_text[0] = 0;
  while ((tok = scanner()) != SCANEOF)
  {
    printf("token: %s, text: '%s'\n", tok_names[tok], last_text);
  }
}
#endif
