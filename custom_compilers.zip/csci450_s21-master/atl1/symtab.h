/* symtab.h: Definitions for the symbol table. */
#pragma once

enum type_kind
{
    tk_SCALAR,
    tk_ARRAY,
    tk_STRING,
    tk_ERROR
};
enum id_kind
{
    ik_VAR,
    ik_PROC,
    ik_PARAM,
    ik_FUNC,
    ik_CONST,
    ik_TYPE,
    ik_LIST
};
enum param_kind
{
    p_VAL,
    p_VAR
};

typedef struct syntax_node *s_node;

typedef struct type_desc
{
    enum type_kind kind;
    int size, low, high;
    //should low, high, and el_type be in a union? How are these defined for scalar/strings?
    struct type_desc *el_type;
} * type_ptr;

typedef struct id_info
{
    char *name;
    type_ptr type;
    enum id_kind kind;
    struct id_info *next;
    union
    {
        /* ik_VAR */
        struct
        {
            int level, offset;
        } var;
        /* ik_PROC and ik_FUNC */
        struct
        {
            int level, data_size, param_size;
            //address?
            //copy of the kv_tree?
            struct id_info *params;
        } pf;
        /*ik_PARAM*/
        struct
        {
            //p_kind is value or variable
            enum param_kind p_KIND;
            int level, offset, size;
            s_node default_AST;
        } param;
        /*ik_CONST*/
        struct
        {
            int value;
        } constant;
    } u;
} * id_ptr;