/* symtab.c : symbol table routines. */
#include "defs.h"
#include "global.h"
#include <string.h>
#include <stdlib.h>

/*kv_tree_array is a pointer to the 2nd element in zero_index_array, which allows us to index 
kv_tree_array starting at -1*/
static struct kv_rec zero_index_array[17];
static struct kv_rec *kv_tree_array = &zero_index_array[1];

//constructs a type descriptor
type_ptr make_type(enum type_kind kind, int size, int low, int high, struct type_desc *el_type)
{
    type_ptr new_type = malloc(sizeof(struct type_desc));
    new_type->kind = kind;
    new_type->size = size;
    if (kind == tk_ARRAY)
    {
        if (low < high)
        {
            new_type->low = low;
            new_type->high = high;
            new_type->el_type = el_type;
        }
        else
        {
            yyerror("Invalid array declaration");
        }
    }
    return new_type;
}

//creates a new kv_tree if there is room to create a new one.
void new_scope()
{
    if (current_lvl < 15)
    {
        current_lvl++;
        kv_init(&kv_tree_array[current_lvl]);
    }
    else
    {
        yyerror("There are already 16 scopes defined.");
    }
}

//decrements the scope
void end_scope()
{
    current_lvl--;
}

//constructs an id ptr
id_ptr make_id(char *name, type_ptr type, enum id_kind kind, struct id_info *next, ...)
{
    //construct the id_struct
    va_list args;
    id_ptr new_type = malloc(sizeof(struct id_info));
    new_type->name = name;
    new_type->type = type;
    new_type->next = next;
    new_type->kind = kind;

    va_start(args, next);
    switch (kind)
    {
    case ik_VAR:
        new_type->u.var.level = current_lvl;
        new_type->u.var.offset = va_arg(args, int);
        break;
    case ik_PROC:
    case ik_FUNC:
        new_type->u.pf.level = current_lvl;
        new_type->u.pf.data_size = va_arg(args, int);
        new_type->u.pf.param_size = va_arg(args, int);
        new_type->u.pf.params = va_arg(args, id_ptr *);
        break;
    case ik_PARAM:
        new_type->u.param.p_KIND = va_arg(args, enum param_kind);
        ;
        new_type->u.param.level = current_lvl;
        new_type->u.param.offset = va_arg(args, int);
        new_type->u.param.size = va_arg(args, int);
        break;
    case ik_CONST:
        new_type->u.constant.value = va_arg(args, int);
        break;
    }
    va_end(args);
    return new_type;
}

//attempts to enter the id into the current_lvl. If it is unsuccessful,
//either by error or by duplicate insert, then it returns an error.
void Enter_ID(id_ptr id)
{
    if (kv_insert(&kv_tree_array[current_lvl], id->name, id) != 1)
    {
        yyerror("Could not insert ID because it already defined.");
        //overload would go here, where we would Find_ID, then link the found ID to the end of this ID's next
    }
}

//searches the current level/scope for the ID
//if it is not in the current, then it goes back a scope
//and continues through the scope array until it gets to -1
//if it is not in -1, then return null.
id_ptr Find_ID(char *name)
{
    for (int i = current_lvl; i >= -1; i--)
    {
        id_ptr id = kv_find(&kv_tree_array[i], name);

        if (id != NULL)
        {
            return id;
        }
    }
    return NULL;
}

//updates the data fields of the current_ID ptr
void declare_variable(id_ptr current_ID, type_ptr type)
{
    current_ID->type = type;
    current_ID->kind = ik_VAR;
    current_ID->u.var.level = current_lvl;
    //current_ID.offset = 1;
}

//creates a new procedure or function
void new_pf(char *name, type_ptr type, id_ptr param_list)
{
    //creating the new pf id
    id_ptr new_PF;
    if (type != NULL)
    {
        new_PF = make_id(name, type, ik_PROC, NULL, current_lvl, /*datasize, paramsize*/ param_list);
    }
    else
    {
        new_PF = make_id(name, NULL, ik_FUNC, NULL, current_lvl, /*datasize, paramsize*/ param_list);
    }
    current_prog = new_PF;
    Enter_ID(new_PF);
    //incrementing the scope
    new_scope();
}

//appends a new parameter list to the end of the old parameter list
id_ptr append_id(id_ptr new_param, id_ptr old_param)
{
    id_ptr next = old_param;
    //this loop finds the last item in the list
    while (next->next != NULL)
    {
        next = next->next;
    }
    //appending the new list to the end of the old list
    next->next = new_param;
    return old_param;
}

//iterates through an id_list and updates the type, kind, and size of each id
void define_params(id_ptr id_list, type_ptr type, char *kind, ...)
{
    va_list args;
    id_ptr next = id_list;
    while (next != NULL)
    {
        next->type = type;
        next->kind = ik_PARAM; //does this change from ik_LIST to ik_PARAM?
        va_start(args, kind);

        next->u.param.p_KIND = va_arg(args, enum param_kind);
        next->u.param.size = 1; //is it 1?
        next->u.param.level = current_lvl;
        next->u.param.default_AST = va_arg(args, s_node);

        va_end(args);
        next = next->next;
    }
    return id_list;
}

//Reverses the order of the params, updates the offset, and inserts the param to the current scope
id_ptr reverse_params(id_ptr params)
{
    int param_offset = -1;
    id_ptr last_next;
    id_ptr next = params;
    id_ptr next_next;

    param_offset -= params->u.param.size;
    params->u.param.offset = param_offset;
    Enter_ID(params);

    last_next = params;
    next = params->next;
    params->next = NULL;

    while (next != NULL)
    {
        param_offset -= next->u.param.size;
        next->u.param.offset = param_offset;
        Enter_ID(next);

        next_next = next->next;
        next->next = last_next;
        last_next = next;
        next = next_next;
    }
    //by the end of this loops, the head of the list is last_next
    return last_next;
}

//prints for debugging
//prints the details of a type descriptor
void print_type(type_ptr type)
{
    switch (type->kind)
    {
    case tk_ARRAY:
        printf("Type kind: array\nType size: %d\n Index: %d\nEnd: %d\nElement Type: \n", type->size, type->low, type->high);
        print_type(type->el_type);
        break;
    case tk_STRING:
        printf("Type kind: string\nType size: %d\n ", type->size);
        break;
    case tk_SCALAR:
        printf("Type kind: scalar\nType size: %d\n ", type->size);
        break;
    case tk_ERROR:
        printf("Type kind: error\nType size: %d\n ", type->size);
        break;
    }
}

//prints the details of each predefined type_ptr
void print_type_ptr(type_ptr type)
{
    if (type == int_ptr)
    {
        printf("(scalar - int)\n");
    }
    else if (type == bool_ptr)
    {
        printf("(scalar - bool)\n");
    }
    else if (type == error_ptr)
    {
        printf("(error)");
    }
    else if (type == string_ptr)
    {
        printf("(string)");
    }
}

//prints the details of an ID
void print_id(id_ptr printing)
{
    printf("ID: ");
    if (printing->kind == ik_PROC)
    {
        printf("proc \"%s\" \n    level = %d, num = N/A, datasize = N/A, paramsize = N/A\n", printing->name, printing->u.pf.level);
        print_id(printing->next);
    }
    else if (printing->kind == ik_FUNC)
    {
        printf("func \"%s\" \n    level = %d, num = N/A, datasize = N/A, paramsize = N/A, returns: ", printing->name, printing->u.pf.level);
        print_type_ptr(printing->type);
        print_id(printing->next);
    }
    else if (printing->kind == ik_VAR)
    {
        printf("var \"%s\"", printing->name);
        print_type_ptr(printing->type);
        printf("    level = %d, offset = N/A\n", printing->u.var.level);
    }
    else if (printing->kind == ik_PARAM)
    {
        printf("param \"%s\"", printing->name);
        print_type_ptr(printing->type);
        if (printing->u.param.p_KIND == p_VAL)
        {
            printf("    value,");
        }
        else
        {
            printf("    variable,");
        }
        printf(" level: %d, offset: %d, size: %d\n", printing->u.param.level, printing->u.param.offset, printing->u.param.size);
        if (printing->next != NULL)
        {
            print_id(printing->next);
        }
    }
    else if (printing->kind == ik_CONST)
    {
        printf("const \"%s\"", printing->name);
        print_type_ptr(printing->type);
    }
    else if (printing->kind == ik_TYPE)
    {
        printf("type \"%s\"", printing->name);
        print_type_ptr(printing->type);
    }
}

//should print all of the nodes in the symbol table, but I didn't know how
//to use kv_visit so I was unable to implement this.
void print_st()
{
    printf("print_st has not been implemented yet.");
    //-- use kv_visit to print a kv_tree.
    //not sure how to use kv_visit
}

/* Initialize the ATL/1 symbol table. */
void init_symtab(char *progname)
{

    kv_init(&kv_tree_array[current_lvl]);
    int_ptr = make_type(tk_SCALAR, 1, 0, 0, NULL);
    string_ptr = make_type(tk_STRING, 1, 0, 0, NULL);
    bool_ptr = make_type(tk_SCALAR, 1, 0, 0, NULL);
    error_ptr = make_type(tk_ERROR, 1, 0, 0, NULL);

    //integer type
    id_ptr integer_ID = make_id("integer", int_ptr, ik_TYPE, NULL);
    Enter_ID(integer_ID);

    //boolean type
    id_ptr boolean_ID = make_id("boolean", bool_ptr, ik_TYPE, NULL);
    Enter_ID(boolean_ID);

    //true, false values
    id_ptr true_ptr = make_id("true", bool_ptr, ik_CONST, NULL, 1);
    id_ptr false_ptr = make_id("false", bool_ptr, ik_CONST, NULL, 0);
    Enter_ID(true_ptr);
    Enter_ID(false_ptr);

    //writeln()
    id_ptr writeln_ptr = make_id("writeln", string_ptr, ik_PROC, NULL, -1 /*offset, value??*/, NULL);
    Enter_ID(writeln_ptr);

    //abs(int);
    id_ptr temp_id_ptr = make_id("arg", int_ptr, ik_PARAM, NULL, -1 /*offset, value??*/);
    id_ptr abs_ptr = make_id("abs", int_ptr, ik_FUNC, NULL, -1, /* datasize, paramsize*/ temp_id_ptr);
    Enter_ID(abs_ptr);

    //read(int);
    id_ptr temp_args = make_id("arg", int_ptr, ik_PARAM, NULL, -1 /*offset, value??*/);
    id_ptr read_ptr = make_id("read", NULL, ik_PROC, NULL, -1, /*datasize, paramsize*/ temp_args);
    Enter_ID(read_ptr);

    //write(int, field);
    id_ptr field_ptr = make_id("field", int_ptr, ik_PARAM, NULL, -1 /*level, offset, value??, default_value*/);
    id_ptr int_value_ptr = make_id("value", int_ptr, ik_PARAM, field_ptr, NULL, -1 /*offset, value??*/);
    id_ptr write_int_ptr = make_id("write", NULL, ik_PROC, NULL, -1, /*datasize, paramsize*/ int_value_ptr);

    //write(bool, field);
    id_ptr field2_ptr = make_id("field", int_ptr, ik_PARAM, NULL, -1 /*offset, value??, default_value*/);
    id_ptr bool_value_ptr = make_id("value", bool_ptr, ik_PARAM, field2_ptr, NULL, -1 /*level, offset, value??*/);
    id_ptr write_bool_ptr = make_id("write", NULL, ik_PROC, write_int_ptr, -1, /*datasize, paramsize*/ bool_value_ptr);

    //write(string, field);
    id_ptr field3_ptr = make_id("field", int_ptr, ik_PARAM, NULL, -1 /*offset, value??, default_value*/);
    id_ptr str_value_ptr = make_id("value", int_ptr, ik_PARAM, field3_ptr, NULL, -1 /* offset, value??*/);
    id_ptr write_str_ptr = make_id("write", NULL, ik_PROC, write_bool_ptr, -1, /*datasize, paramsize*/ str_value_ptr);

    //entering all of the write functions
    Enter_ID(write_str_ptr);

    //creating the level 0 scope
    new_scope();

    //inserting the program name
    id_ptr program_name = make_id(progname, string_ptr, ik_VAR, NULL, 0 /*offset?*/);
    Enter_ID(program_name);
    current_prog = program_name;
}
