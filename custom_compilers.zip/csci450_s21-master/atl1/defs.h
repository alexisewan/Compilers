/* defs.h:  Common definitions and includes for ATL/0.  */

/* The includes .... */
#include <stdio.h>
#include <stdbool.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <unistd.h>
#include "kv_tree.h"
#include "symtab.h"
#include "syntree.h"

/* Some defines to use. */
#define FALSE 0
#define TRUE 1

/* Global function prototypes. */

/* From util.c - - */
void generate(char *fmt, ...);
void label(char *lab, ...);
void yyerror(char *mesg, ...);
void *my_malloc(int size);
void dump_errors(void);

/* From scan.c */
int yylex(void);

/* From parse.c - - */
int yyparse(void);

/* From symtab.c */
void init_symtab(char *progname);
type_ptr make_type(enum type_kind kind, int size, int low, int high, struct type_desc *el_type);
void new_scope();
void end_scope();
id_ptr make_id(char *name, type_ptr type, enum id_kind kind, struct id_info *next, ...);
void Enter_ID(id_ptr id);
id_ptr Find_ID(char *name);
void declare_variable(id_ptr current_ID, type_ptr type);
void new_pf(char *name, type_ptr type, id_ptr param_list);
id_ptr append_id(id_ptr new_param, id_ptr old_param);
void define_params(id_ptr id_list, type_ptr type, char *kind, ...);
id_ptr reverse_params(id_ptr params);
void print_type(type_ptr type);
void print_type_ptr(type_ptr type);
void print_id(id_ptr printing);
void print_st();
void init_symtab(char *progname);

/* From syntree.c */
s_node make_node(enum node_kind kind, type_ptr type, s_node *next, ...);
s_node append_node(s_node new_param, s_node old_param);
void make_func(char *func_name, s_node aparams);
bool compare_params(s_node aparams, id_ptr fparams);

/* From gen.c */
