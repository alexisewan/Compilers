/* syntree.c: Code to maniuplate syntax trees. */
#include "defs.h"
#include "global.h"
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

//constructs an s_node
s_node make_node(enum node_kind kind, type_ptr type, s_node *next, ...)
{
    va_list args;
    s_node new_node = malloc(sizeof(struct syntax_node));
    new_node->kind = kind;
    new_node->type = type;
    new_node->line_num = line_no;
    new_node->next = next;
    va_start(args, next);
    switch (kind)
    {
    case ak_BINARY:
        new_node->u.binary.operator=(char *) va_arg(args, int);
        new_node->u.binary.expr1 = va_arg(args, s_node);
        new_node->u.binary.expr2 = va_arg(args, s_node);
        new_node->u.binary.return_type = va_arg(args, type_ptr);
        break;
    case ak_UNARY:
        new_node->u.unary.operator=(char *) va_arg(args, int);
        new_node->u.unary.expr1 = va_arg(args, s_node);
        new_node->u.unary.return_type = va_arg(args, type_ptr);
        break;
    case ak_FUNC:
        new_node->u.func.func_def = va_arg(args, id_ptr);
        new_node->u.func.aparams = va_arg(args, s_node);
        new_node->u.func.return_type = va_arg(args, type_ptr);
        break;
    case ak_SVAR:
        char *variable_name = (char *)va_arg(args, int);
        id_ptr variable = Find_ID(variable);
        new_node->u.simple.variable = variable;
        new_node->u.simple.type = variable->type;
        break;
    case ak_IVAR:
        char *variable_name = (char *)va_arg(args, int);
        id_ptr variable = Find_ID(variable);
        s_node expr = va_arg(args, s_node);
        if (variable->type->kind == tk_ARRAY)
        {
            if (variable->kind == ik_VAR || variable->kind == ik_PARAM)
            {
                if (expr->kind == ak_CONST)
                {
                    new_node->u.index.index = expr->u.int_const.value;
                }
            }
        }
        new_node->u.index.index = va_arg(args, int);
        break;
    case ak_CONST:
        new_node->u.int_const.value = va_arg(args, int);
        break;
    case ak_STRING:
        new_node->u.string.string = (char *)va_arg(args, int);
        break;
    case ak_PAREN:
        new_node->u.paren.expr = va_arg(args, s_node);
        break;
    case ak_ERROR:
        new_node->type = error_ptr;
        break;
    case ak_BOOL:
        new_node->type = bool_ptr;
        break;
    case ak_APARAM:
        new_node->u.aparam.expr1 = va_arg(args, s_node);
        break;
    case ak_ASSIGN:
        s_node expr = va_arg(args, s_node);
        s_node variable = va_arg(args, id_ptr);

        if (expr->type == variable->type)
        {
            //other necessary type-checking is done when the variable is initialized.
            new_node->u.assign.expr = expr;
            new_node->u.assign.variable = variable;
        }
        else
        {
            new_node->type = error_ptr;
            new_node->kind = ak_ERROR;
        }
        break;
    case ak_IF:
        s_node control = va_arg(args, s_node);
        if (control->type == bool_ptr)
        {
            new_node->u.if_node.control_expr = control;
        }
        new_node->u.if_node.then_tree = reverse_list(va_arg(args, s_node));
        new_node->u.if_node.elseif_tree = va_arg(args, s_node);
        new_node->u.if_node.else_tree = va_arg(args, s_node);
        break;
    case ak_ELSEIF:
        s_node control = va_arg(args, s_node);
        if (control->type == bool_ptr)
        {
            new_node->u.elseif_node.control_expr = control;
        }
        new_node->u.elseif_node.then_tree = reverse_list(va_arg(args, s_node));
        new_node->u.elseif_node.elseif_tree = va_arg(args, s_node);
        break;
    case ak_RETURN:
        s_node return_expr = va_arg(args, s_node);
        if (current_prog->kind == ik_FUNC)
        {
            if (current_prog->kind != return_expr->type)
            {
                new_node->u.return_expr.return_expr = return_expr;
            }
            else
            {
                new_node->type = error_ptr;
                new_node->kind = ak_ERROR;
            }
        }
        else
        {
            new_node->type = error_ptr;
            new_node->kind = ak_ERROR;
        }
        break;
    case ak_LOOP:
        s_node control = va_arg(args, s_node);
        if (control->type == bool_ptr)
        {
            new_node->u.loop.control_expr = control;
        }

        new_node->u.loop.action_list = reverse_list(va_arg(args, s_node));
        break;
    }
    va_end(args);

    return new_node;
}

//appends the new_params to the end of the old_params
s_node append_node(s_node new_param, s_node old_param)
{
    s_node next = old_param;
    //this loop finds the last item in the list
    while (next->next != NULL)
    {
        next = *next->next;
    }
    //appending the new list to the end of the old list
    next->next = &new_param;
    return old_param;
}

//creates an s_node for a function call
void make_func(char *func_name, s_node aparams)
{
    s_node new_node = malloc(sizeof(struct syntax_node));

    new_node->u.func.aparams = reverse_list(aparams);

    id_ptr func_def = Find_ID(func_name);
    while (func_def != NULL)
    {
        if (compare_params(aparams, func_def->u.pf.params))
        {
            new_node->u.func.func_def = func_def;
            new_node->type = func_def->type;
            new_node->u.func.return_type = func_def->type;
            break;
        }
        else
        {
            func_def = func_def->next;
        }
    }
    if (func_def == NULL)
    {
        new_node->u.func.func_def = NULL;
        new_node->type = NULL;
        new_node->u.func.return_type = NULL;
    }
}

//compares the parameters of a function call and the function it is calling
//to ensure it is the correct usage.
bool compare_params(s_node aparams, id_ptr fparams)
{
    s_node aNext = aparams;
    id_ptr fNext = fparams;

    while (aNext != NULL && fNext != NULL)
    {
        if (aNext->u.aparam.expr1->type == fNext->type)
        {
            aNext = aNext->next;
            fNext = fNext->next;
        }
        else if (aNext->u.aparam.expr1 == NULL && fNext->u.param.default_AST != NULL)
        {
            aNext = aNext->next;
            fNext = fNext->next;
        }
        else
        {
            return false;
        }
    }
    if (aNext == NULL && fNext != NULL)
    {
        while (fNext != NULL)
        {
            if (fNext->u.param.default_AST == NULL)
            {
                return false;
            }
        }
    }
    else if (aNext != NULL && fNext == NULL)
    {
        return false;
    }

    aNext = aparams;
    fNext = fparams;
    while (aNext != NULL && fNext != NULL)
    {
        if (aNext->u.aparam.expr1 == NULL)
        {
            aNext->u.aparam.expr1 = fNext->u.param.default_AST;
        }
    }
    return TRUE;
}

//multiple actual params (maparam)
//gives us a list of several aparam lists linked together via maparams node
//finds the function that matches each maparams aparam list
//and points the func_node->u.func.func_def to the function that is found
//also reverses the maparams list
s_node make_proc(char *proc_name, s_node maparams)
{
    s_node new_node = malloc(sizeof(struct syntax_node));
    new_node->kind = ak_FUNC;
    s_node prev_node = NULL;
    id_ptr funcs = Find_ID(proc_name);
    s_node mNext = maparams;
    id_ptr fNext = funcs;
    while(mNext != NULL){
        id_ptr funcs = Find_ID(proc_name);
        bool compared = false;
        while(!compared){
            compared = compare_params(mNext->next, fNext->u.pf.params);
            if(compared){
                mNext->u.func.aparams = mNext->next;
                mNext->u.func.func_def = fNext;
                new_node->type = fNext->type;
                new_node->u.func.return_type = fNext->type;
                break;
            }else{
                fNext = fNext->next;
            }

            if (fNext == NULL)
            {
                new_node->u.func.func_def = NULL;
                new_node->type = NULL;
                new_node->u.func.return_type = NULL;
                break;
            }
        }
        mNext = mNext->u.mparam.next_mparam;
        fNext = funcs;
        if(prev_node != NULL){
            new_node->next = prev_node;
        }
        prev_node = new_node;
    }
    return new_node;
}

//used to reverse a list of s_nodes
s_node reverse_list(s_node list){
    s_node next = list;
    s_node next_next = list->next;
    s_node prev_next = NULL;

    while (next != NULL)
    {
        next_next = next->next;
        next->next = prev_next;
        prev_next = next;
        next = next_next;
    }
    return prev_next;
}
