/* util.c: Utility routines for use with ATL/1. */

/* Get the common definitions and includes. */
#include "defs.h"

/* Variables declared elsewhere.... */
#include "global.h"


/* Variables for here only! */
static int has_label = FALSE;

/* generate:  A function that writes assembly instructions to the 
   assembly file.  The parameters are very similar to printf.

     Examples:
	generate ("add");	(generates the add instruction.)
        generate ("load %d,%d", level, offset)
				(generates a load with level and offset
				 as integer data.)

*/

void generate (char *opcode_fmt ,...)
{
  va_list args;

  va_start (args, opcode_fmt);
  fprintf (asm_out, "\t");
  vfprintf (asm_out, opcode_fmt, args);
  fprintf (asm_out, "\n");
  va_end (args);
  has_label = FALSE;
}


/* label() defines a label at the beginning of an assembly line. */
void label (char *lab,...)
{
  va_list args;
  char chars[128];

  if (has_label)
    fprintf (asm_out, "\n");
  va_start (args, lab);
  vsprintf (chars, lab, args);
  fprintf (asm_out, "%s: ", chars);
  va_end (args);
  has_label = TRUE;
}

/* label_def() defines a label as a value. */
void label_def (int value, char *lab,...)
{
  va_list args;
  char chars[128];

  if (has_label)
    fprintf (asm_out, "\n");
  va_start (args, lab);
  vsprintf (chars, lab, args);
  fprintf (asm_out, "%s=%d\n", chars, value);
  va_end (args);
  has_label = TRUE;
}


/* The standard yyerror routine.  Built with variable number of argumnets.
   Errors are accumulated until the end of the line.  At that point, all
   errors are printed.
   */

struct list { char *error; struct list *next; };
struct list *first = NULL, *last, *tmp;

void
  yyerror (char *str, ...)
{
  char buff1[256];
  char buff2[256];
  va_list args;
  
  va_start (args, str);
  sprintf (buff1,"%s:%d: ",src_name,line_no);
  vsprintf (buff2, str, args);
  strcat (buff1,buff2);
  if (list_src)
    {
      tmp = (struct list *) malloc (sizeof(struct list));
      tmp->error = strdup (buff1);
      tmp->next = NULL;
      if (first == NULL)
	first = tmp;
      else
	last->next = tmp;
      last = tmp;
    } else {
      fprintf (stderr, "%s\n", buff1);
    }
  va_end (args);
  had_errors = TRUE;
}

void dump_errors (void)
{
  struct list *temp;
  
  while (first != NULL)
    {
      fprintf (stderr, "%s\n", first->error);
      free (first->error);
      temp = first;
      first = first->next;
      free (temp);
    }
}

/* A malloc that generates errors.... */

void *my_malloc (int size)
{
  void *temp;

  temp = (void *) malloc (size);
  if (temp != NULL) return temp;

  yyerror ("Malloc failed!");
  exit (2);
}


