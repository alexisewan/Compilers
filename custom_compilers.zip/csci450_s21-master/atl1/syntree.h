/* syntree.h: Definitions for an abstract syntax tree. */
#pragma once
enum node_kind
{
    ak_BINARY,
    ak_UNARY,
    ak_FUNC,
    ak_SVAR,
    ak_IVAR,
    ak_PAREN,
    ak_ERROR,
    ak_BOOL,
    ak_CONST,
    ak_STRING,
    ak_APARAM,
    ak_MPARAM,
    ak_ASSIGN,
    ak_IF,
    ak_ELSEIF,
    ak_RETURN,
    ak_LOOP
};

typedef struct syntax_node
{
    enum node_kind kind;
    type_ptr type;
    int line_num;
    s_node *next;
    union
    {
        /*ak_BINARY*/
        //+, -, *, /, %, &&, ||, <, >, etc.
        struct
        {
            char *operator;
            s_node expr1;
            s_node expr2;
            type_ptr return_type;
        } binary;
        /*ak_UNARY*/
        //!expr, -expr
        struct
        {
            char operator;
            s_node expr1;
            type_ptr return_type;
        } unary;
        /*ak_FUNC*/
        struct
        {
            id_ptr func_def;
            s_node aparams;
            type_ptr return_type;
        } func;
        /*ak_SVAR*/
        struct
        {
            id_ptr variable;
            type_ptr type;
        } simple;
        /*ak_IVAR*/
        struct
        {
            int index;
        } index;
        /*ak_CONST*/
        struct
        {
            int value;
        } int_const;
        /*ak_STRING*/
        struct
        {
            char *string;
        } string;
        /*ak_PAREN*/
        struct
        {
            s_node expr;
        } paren;
        /*ak_APARAM*/
        struct
        {
            s_node expr1;
        } aparam;
        /*ak_MPARAM*/
        struct{
            s_node *next_mparam;
        } mparam;
        /*ak_ASSIGN*/
        struct
        {
            s_node expr;
            id_ptr variable;
            //variable?
        } assign;
        /*ak_IF*/
        struct
        {
            s_node control_expr;
            s_node then_tree;
            s_node elseif_tree;
            s_node else_tree;
        } if_node;
        /*ak_ELSEIF*/
        struct
        {
            s_node control_expr;
            s_node then_tree;
            s_node elseif_tree;
        } elseif_node;
        /*ak_RETURN*/
        struct
        {
            s_node return_expr;
        } return_expr;
        /*ak_LOOP*/
        struct
        {
            s_node control_expr;
            s_node action_list;
        } loop;
    } u;
} * s_node;
