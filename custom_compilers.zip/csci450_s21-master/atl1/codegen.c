/* codegen.c:  The code generations routines for ATL/1. */

#include "defs.h"
#include "global.h"